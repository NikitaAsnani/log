/**
 * 
 */
package com.capgemini.mcd.ccs.sharedlibrary.logging;

/**
 * @author nasnani
 *
 */
public class LogSettings {
	
	private String[] logLevel;
	private boolean fileLogger;
	private boolean cloudWatchLogger;
	private boolean microServiceLogger;
	private int maxFileSize;
	private long maxLogRotation;
	
	LogSettings(){
	}

	/**
	 * @return the logLevel
	 */
	public String[] getLogLevel() {
		return logLevel;
	}

	/**
	 * @param logLevel the logLevel to set
	 */
	public void setLogLevel(String[] logLevel) {
		this.logLevel = logLevel;
	}

	/**
	 * @return the fileLogger
	 */
	public boolean isFileLogger() {
		return fileLogger;
	}

	/**
	 * @param fileLogger the fileLogger to set
	 */
	public void setFileLogger(boolean fileLogger) {
		this.fileLogger = fileLogger;
	}

	/**
	 * @return the cloudWatchLogger
	 */
	public boolean isCloudWatchLogger() {
		return cloudWatchLogger;
	}

	/**
	 * @param cloudWatchLogger the cloudWatchLogger to set
	 */
	public void setCloudWatchLogger(boolean cloudWatchLogger) {
		this.cloudWatchLogger = cloudWatchLogger;
	}

	/**
	 * @return the microServiceLogger
	 */
	public boolean isMicroServiceLogger() {
		return microServiceLogger;
	}

	/**
	 * @param microServiceLogger the microServiceLogger to set
	 */
	public void setMicroServiceLogger(boolean microServiceLogger) {
		this.microServiceLogger = microServiceLogger;
	}

	/**
	 * @return the maxFileSize
	 */
	public int getMaxFileSize() {
		return maxFileSize;
	}

	/**
	 * @param maxFileSize the maxFileSize to set
	 */
	public void setMaxFileSize(int maxFileSize) {
		this.maxFileSize = maxFileSize;
	}

	/**
	 * @return the maxLogRotation
	 */
	public long getMaxLogRotation() {
		return maxLogRotation;
	}

	/**
	 * @param maxLogRotation the maxLogRotation to set
	 */
	public void setMaxLogRotation(long maxLogRotation) {
		this.maxLogRotation = maxLogRotation;
	}
	
	public void configureLogSettings(){
		
	}
	
	public void updateLog4jConfigurations(){
		
	}
	
}
