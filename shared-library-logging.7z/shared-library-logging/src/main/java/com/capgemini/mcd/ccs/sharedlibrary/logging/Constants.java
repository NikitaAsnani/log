/**
 * 
 */
package com.capgemini.mcd.ccs.sharedlibrary.logging;

/**
 * @author nasnani
 *
 */
public class Constants {

	public final static String CORRELATION_ID="correlationId";
	public static String TIMESTAMP;
	public static String SEVERITY;
	public static String SESSION_ID;
	public static String REQUEST_ID;
	public static String MESSAGE;
	public static String ERROR_CODE;
	public static String STACK_TRACE;
	public static String APPLICATION_NAME;
	public static String CLASS_NAME;
	public static String METHOD_ID;
	public static String PROCESS_ID;
	public static String AWS_META_DATA_HOST;
	public static String AWS_META_DATA_CONTEXT;
	public static String HOST_AZ;
	public static String HOST_ID;
	public static String APPLICATION_ROLE;
	public static String MARKET_ID;
	public static String APPLICATION_VERSION;
	public static String LOG_FORMAT;
	public static String MAX_FILE_SIZE;
	public static String MAX_ROLLOVER_SIZE;
	
}
