/**
 * 
 */
package com.capgemini.mcd.ccs.sharedlibrary.logging;

import org.apache.logging.log4j.Logger;
import org.json.simple.JSONObject;

/**
 * @author nasnani
 *
 */
public class FileLogger extends Helper implements ILogger{
	
	private Logger logger;
	private String logEntry;
	
	public FileLogger() {
	}
	
	public void debug(JSONObject jsonObj) {
		logger.debug(jsonObj);
	}
	public void info(JSONObject jsonObj) {
		logger.info(jsonObj);
	}
	public void warn(JSONObject jsonObj) {
		logger.warn(jsonObj);
	}
	public void error(JSONObject jsonObj) {
		logger.error(jsonObj);
	}
	public void fatal(JSONObject jsonObj) {
		logger.fatal(jsonObj);
	}
	public void writeToFile(JSONObject jsonObj) {
		
	}
	
}
