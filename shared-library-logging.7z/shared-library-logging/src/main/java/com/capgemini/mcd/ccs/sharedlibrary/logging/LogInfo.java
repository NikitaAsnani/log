/**
 * 
 */
package com.capgemini.mcd.ccs.sharedlibrary.logging;

/**
 * @author nasnani
 *
 */
public class LogInfo {
	
	private String correlationId;
	private String timeStamp;
	private String applicationRole;
	private String applicationName;
	private String method;
	private String tagName;
	private String marketID;
	private String applicationVersion;
	private String processID;
	private String sessionID;
	private String requestID;
	private String hostAZ;
	private String hostID;
	private String hostLayer;
	private String hostIP;
	private String message;
	private String errorCode;
	private String stackTrace;
	
	public LogInfo() {
	}

	/**
	 * @return the correlationId
	 */
	public String getCorrelationId() {
		return correlationId;
	}

	/**
	 * @param correlationId the correlationId to set
	 */
	public void setCorrelationId(String correlationId) {
		this.correlationId = correlationId;
	}

	/**
	 * @return the timeStamp
	 */
	public String getTimeStamp() {
		return timeStamp;
	}

	/**
	 * @param timeStamp the timeStamp to set
	 */
	public void setTimeStamp(String timeStamp) {
		this.timeStamp = timeStamp;
	}

	/**
	 * @return the applicationRole
	 */
	public String getApplicationRole() {
		return applicationRole;
	}

	/**
	 * @param applicationRole the applicationRole to set
	 */
	public void setApplicationRole(String applicationRole) {
		this.applicationRole = applicationRole;
	}

	/**
	 * @return the applicationName
	 */
	public String getApplicationName() {
		return applicationName;
	}

	/**
	 * @param applicationName the applicationName to set
	 */
	public void setApplicationName(String applicationName) {
		this.applicationName = applicationName;
	}

	/**
	 * @return the method
	 */
	public String getMethod() {
		return method;
	}

	/**
	 * @param method the method to set
	 */
	public void setMethod(String method) {
		this.method = method;
	}

	/**
	 * @return the tagName
	 */
	public String getTagName() {
		return tagName;
	}

	/**
	 * @param tagName the tagName to set
	 */
	public void setTagName(String tagName) {
		this.tagName = tagName;
	}

	/**
	 * @return the marketID
	 */
	public String getMarketID() {
		return marketID;
	}

	/**
	 * @param marketID the marketID to set
	 */
	public void setMarketID(String marketID) {
		this.marketID = marketID;
	}

	/**
	 * @return the applicationVersion
	 */
	public String getApplicationVersion() {
		return applicationVersion;
	}

	/**
	 * @param applicationVersion the applicationVersion to set
	 */
	public void setApplicationVersion(String applicationVersion) {
		this.applicationVersion = applicationVersion;
	}

	/**
	 * @return the processID
	 */
	public String getProcessID() {
		return processID;
	}

	/**
	 * @param processID the processID to set
	 */
	public void setProcessID(String processID) {
		this.processID = processID;
	}

	/**
	 * @return the sessionID
	 */
	public String getSessionID() {
		return sessionID;
	}

	/**
	 * @param sessionID the sessionID to set
	 */
	public void setSessionID(String sessionID) {
		this.sessionID = sessionID;
	}

	/**
	 * @return the requestID
	 */
	public String getRequestID() {
		return requestID;
	}

	/**
	 * @param requestID the requestID to set
	 */
	public void setRequestID(String requestID) {
		this.requestID = requestID;
	}

	/**
	 * @return the hostAZ
	 */
	public String getHostAZ() {
		return hostAZ;
	}

	/**
	 * @param hostAZ the hostAZ to set
	 */
	public void setHostAZ(String hostAZ) {
		this.hostAZ = hostAZ;
	}

	/**
	 * @return the hostID
	 */
	public String getHostID() {
		return hostID;
	}

	/**
	 * @param hostID the hostID to set
	 */
	public void setHostID(String hostID) {
		this.hostID = hostID;
	}

	/**
	 * @return the hostLayer
	 */
	public String getHostLayer() {
		return hostLayer;
	}

	/**
	 * @param hostLayer the hostLayer to set
	 */
	public void setHostLayer(String hostLayer) {
		this.hostLayer = hostLayer;
	}

	/**
	 * @return the hostIP
	 */
	public String getHostIP() {
		return hostIP;
	}

	/**
	 * @param hostIP the hostIP to set
	 */
	public void setHostIP(String hostIP) {
		this.hostIP = hostIP;
	}

	/**
	 * @return the message
	 */
	public String getMessage() {
		return message;
	}

	/**
	 * @param message the message to set
	 */
	public void setMessage(String message) {
		this.message = message;
	}

	/**
	 * @return the errorCode
	 */
	public String getErrorCode() {
		return errorCode;
	}

	/**
	 * @param errorCode the errorCode to set
	 */
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	/**
	 * @return the stackTrace
	 */
	public String getStackTrace() {
		return stackTrace;
	}

	/**
	 * @param stackTrace the stackTrace to set
	 */
	public void setStackTrace(String stackTrace) {
		this.stackTrace = stackTrace;
	}
	
	
}
