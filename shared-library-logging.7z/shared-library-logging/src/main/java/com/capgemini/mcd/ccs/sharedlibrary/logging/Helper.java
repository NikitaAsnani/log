/**
 * 
 */
package com.capgemini.mcd.ccs.sharedlibrary.logging;

import org.json.simple.JSONObject;

/**
 * @author nasnani
 *
 */
public class Helper {

	public String getAWSHostInfo(String hostInfo){
		return hostInfo;
	}
	
	public JSONObject getLogConfigurations(String logConfig){
		return null;
	}
	
	public String getApplicationName(){
		return null;
	}
	
	public String getProcessID(){
		return null;
	}
	
	public String buildLogEntry(JSONObject logEntry){
		return null;
	}
	
}
