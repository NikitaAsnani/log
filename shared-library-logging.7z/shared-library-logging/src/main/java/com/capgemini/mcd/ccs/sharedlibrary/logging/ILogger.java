/**
 * 
 */
package com.capgemini.mcd.ccs.sharedlibrary.logging;

import org.json.simple.JSONObject;

/**
 * @author nasnani
 *
 */
public interface ILogger {

	public void debug(JSONObject jsonObj);
	public void info(JSONObject jsonObj);
	public void warn(JSONObject jsonObj);
	public void error(JSONObject jsonObj);
	public void fatal(JSONObject jsonObj);		
	
}
