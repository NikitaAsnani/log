package com.capgemini.mcd.ccs.sharedlibrary.logging;


import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class LogController {

	private static final Logger logger = LogManager.getLogger(LogController.class);
	
	@RequestMapping("/")
	public String getWelcome() {

		//logs debug message
		if(logger.isDebugEnabled()){
			logger.debug("getWelcome is executed!");
		}
		//logs exception
		logger.trace("getWelcome executed!");
		logger.error("This is Error message");
		
		String msg="Hello Spring + Log4j";
		return msg;

	}

}
